import mongoose from 'mongoose';

const studioSchema=new mongoose.Schema({
name:{
    type:String,
    require:true
},
serviceType:{
    type:String,
    require:true

},
image:{
    type:String,
    require:true
},
city:{
    type:String,
    require:true
}
}
,{ timestamps: true }
);

  
export default mongoose.model("studio",studioSchema);