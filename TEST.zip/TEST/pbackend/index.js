import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv'

import route from './routes/userroutes.js';
const app=express();
app.use(bodyParser.json());
app.use(cors());
dotenv.config();
const PORT=process.env.PORT || 8000;
const MONGO_CON=process.env.MONGO_CON;

mongoose.connect(MONGO_CON)
.then(()=>console.log("DataBase connected !!"));



app.listen(PORT, function () {
  console.log(`backend listening on port ${PORT}!`);
});

app.use("/api/studio",route);